<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['language_abbr'] = array(
    'english'    => 'en',
    'french'     => 'fr',
    'portuguese' => 'pt'
);
